(function () {
    'use strict';

     angular.module('Player', ['ionic', 'Player.controllers', 'Player.services']);

})();
